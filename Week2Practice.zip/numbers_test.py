numberThree = 3
numberFour = 4

math_result = numberThree * numberFour + numberThree

print(math_result)