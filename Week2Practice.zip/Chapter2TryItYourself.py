# try it yourself 2-1
# printing a message and assigning a new value to it
restaurant = "Outback Steakhouse"
print(restaurant)
restaurant = "Ribeye Steak"
print(restaurant)


# try it yourself 2-2
# printing a message using string concatenation
lastBusiness = "Dairy Queen"
lastPurchase = "Chicken basket"
print("The last time I went to " + lastBusiness + ", I purchased " + lastPurchase)

# try it yourself 2-3
favoriteCar = "Corvette"

print(favoriteCar.upper())
print(favoriteCar.lower())
print(favoriteCar.title())

# try it yourself 2-4
favQuote = "\tYou will see me struggle, but you will never see me quit\t"
print(favQuote)
favQuote = "\tYou will see me struggle, but you will never see me quit\t".lstrip()
print(favQuote)
favQuote = "\tYou will see me struggle, but you will never se me quit\t".strip()
print(favQuote)

# try it yourself 2-5
muliplicationProblem = 5 * 5
print(muliplicationProblem)


