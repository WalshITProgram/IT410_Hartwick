numbers = list(range(1,11,2))

print(min(numbers))
print(max(numbers))
print(sum(numbers))
