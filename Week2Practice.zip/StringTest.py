string_var = 'hello\n\t'

string_name = "Joes Hartwick"

print(string_var + string_name)