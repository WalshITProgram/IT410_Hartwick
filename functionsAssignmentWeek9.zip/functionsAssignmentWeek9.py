#declare empty employee data list
employeeData = []


# declare check employee id function
def checkEmployeeId(employeeId):
    # check employee id to see if it is a digit or greater than 7 digits
    employeeIdCheck = employeeId.isdigit()
    if len(employeeId) >= 8 or employeeIdCheck == False:
        return False
    else:
        return True
# declare check employee name function that will check the employee name for bad characters
def checkEmployeeName(name):
    # declare bad characters list for name
    nameBadChars = ['!', '"', '@', '#', '$', '%', '^', '&', '*', '(', ')', '_', '=', '+' ',', '<', '>', '/', '?', ';', ':', '[', ']', '{', '}',')']        

    # for loop to test if any unwanted characters are in the employees name
    hasBadCharacters = False
    for character in nameBadChars:
        if character in name:
            hasBadCharacters = True
    if hasBadCharacters == True:
        return False 
    else: 
        return True
# check employe email function that will check the employees email for formatting
def checkEmployeeEmail(email):
    emailBadChars = ['!', '"', '#', '$', '%', '^', '&', '*', '(', ')', '_', '=', '+' ',', '<', '>', '/', '?', ';', ':', '[', ']', '{', '}',')']
    hasBadCharacters = False
    for character in emailBadChars:
        if character in employeeEmailAddress:
            hasBadCharacters = True
    if hasBadCharacters == True:
        return False
    else:
        return True

def checkEmployeeAddress(address):
    addressBadChars = ['!', '"', "'", '@', '$', '%', '^', '&', '*', '_', '=', '+', '<', '>',  '?', ';', ':', '[', ']', '{', '}', ')']
            
    # for loop to check for bad characters in the address
    hasBadCharacters = False
    for charactor in addressBadChars:
        if charactor in address:
            hasBadCharacters = True
            break
    if hasBadCharacters == True:
        return False
    else: 
        return True

def appendEntryToDictionaryList(employeeId, employeeName, employeeEmail, employeeAddress=''):
    if employeeAddress == '':
        employeeData.append({"EmployeeId": employeeId,"Name": employeeName.title(),"EmailAddress": employeeEmailAddress})
    else:
        employeeData.append({"EmployeeId": employeeId,"Name": employeeName.title(),"EmailAddress": employeeEmailAddress,"HomeAddress": employeeAddress})
#set increment count variable to 0
count = 0
while count < 5:
    # control variable for the employee id loop
    k = False
    while k == False:

        # get employee id from user 
        employeeId = input("Please enter a employee id: ")
        # call employee id checker function 
        employeeIdChecker = checkEmployeeId(employeeId)
        if employeeIdChecker == False:
            k = False
            print("Employee id was not formatted correctly. Please try again. ")
        else:
            k = True
        
    # employee name while loop control variable
    m = False
    while m == False:

        # get employee name from user 
        employeeName = input("Please enter a first name: ")

        # check employee name for anything other than letters 
        employeeNameChecker = checkEmployeeName(employeeName)

        #test to see if bad characters came up in the for loop for address. If so we reprompt the user, otherwise it breaks the loop
        # The loop would also break if there are anything else other than numbers in the name because if employeeNameCheck comes back as false we would reprompt the user
        if employeeNameChecker == False:
            m = False
            print("Employee name was not properly formatted. Please try again. ")
        else:
            m = True
    
    # declare email address control variable     
    h = False
    while h == False:
        # get employee email address from user 
        employeeEmailAddress = input("Please enter an email address: ")

        employeeEmailChecker = checkEmployeeEmail(employeeEmailAddress)
        
        # if there are bad characters in the email or anything other than letters we would reprompt the user. Otherwise we break the email address loop  
        if employeeEmailChecker == False:
            h = False
            print("Employee email was not properly formatted. Please try again. ")
        else:
            h = True

            
    # declare home address control variable 
    c = False
    while c == False: 
        # get employees home address from user 
        employeeAddress = input("Please enter the employee's home address(optional): ")
        
        # call employee address checker function
        employeeAddressChecker = checkEmployeeAddress(employeeAddress)
        # test to see if bad characters came up in the for loop for address. If so we reprompt the user, otherwise we break the loop
        if employeeAddressChecker == False:
            c = False
            print("Address was not properly formatted. Please try again. ")
        else:
            c = True
    # append employee data into the dictionary
    # if an employee address is not provided or invalid the first if statement will be executed If an address is provided the else statement will be executed
    if len(employeeAddress) == 0: 
        appendEntryToDictionaryList(employeeId, employeeName, employeeEmailAddress)
    else: 
        appendEntryToDictionaryList(employeeId, employeeName, employeeEmailAddress, employeeAddress)
    
    # prompt the user if they want to enter another employee
    # if they type N we break the loop and print the dictionairy
    # if they type Y it would prompt them for another users input 
    if count <= 4: 
        enterAnotherEmployee = input("Would you like to enter data for another employee (type Y or N) ").lower()
    else:
        print("You can only enter data for 5 employees at a time. Goodbye!")
        break
    
    if enterAnotherEmployee == "n":
        break
    elif enterAnotherEmployee == "y":
        count += 1
        continue
# print out the employee data dictionary
print("Here are the employee(s) that were entered into our database: ")
print(employeeData)